import pkg_resources
from .utils import parse_CrossTalkeR


def load_peng2019():
    """Return a dataframe about the 68 different Roman Emperors.

    Contains the following fields:
        index          68 non-null int64
        name           68 non-null object
        name.full      68 non-null object
    ... (docstring truncated) ...

    """
    # This is a stream-like object. If you want the actual info, call
    # stream.read()
    stream = pkg_resources.resource_filename(__name__, 'data/peng_ctker.Rds')
    return parse_CrossTalkeR(stream)
