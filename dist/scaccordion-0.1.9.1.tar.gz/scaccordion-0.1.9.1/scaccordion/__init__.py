__version__ = "0.1.8.7"
__author__ = 'James Nagai'
__credits__ = 'Institute for Computational Genomics'

import scaccordion.tools as tl
import scaccordion.plots as pl